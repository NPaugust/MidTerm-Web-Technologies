MidTerm-Web-Technologies
This is midterm project for CS 204 course at AIU CS detpt.
Web Site made by me and about me. 
The page is made entirely by hand. 
HTML / CSS was used. 
The website has things like a navigation menu with transitions, buttons, links, and photos.
Resources were taken from various sources.
Guides:https://www.youtube.com/watch?v=_xkSvufmjEs